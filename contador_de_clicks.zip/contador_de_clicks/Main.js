const escena = new THREE.Scene();
const camara = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);

const renderizador = new THREE.WebGLRenderer();
renderizador.setSize(window.innerWidth, window.innerHeight);
renderizador.setAnimationLoop(animar);
document.body.appendChild(renderizador.domElement);

const formaCubo = new THREE.BoxGeometry(1, 1, 1);
const materialCubo = new THREE.MeshBasicMaterial({ color: 0xffb6c1 });
const cubo = new THREE.Mesh(formaCubo, materialCubo);
escena.add(cubo);

let puntaje = 0;
let incrementoBase = 1;
let multiplicador = 10;
let incrementoAutomatico = 0.0000001;

const contadorPuntos = document.getElementById("contadorPuntos");

function sumarPuntaje() {
  puntaje += incrementoBase * multiplicador;
}

function mejoraUno() {
  incrementoBase++;
}

function mejoraDos() {
  multiplicador++;
}

function mejoraTres() {
  incrementoAutomatico++;
}

addEventListener("click", () => sumarPuntaje());

camara.position.z = 5;

function animar() {
  puntaje += incrementoAutomatico;
  contadorPuntos.innerHTML = Math.floor(puntaje);

  cubo.rotation.x += 0.01;
  cubo.rotation.y += 0.01;

  renderizador.render(escena, camara);
}
